class Store2be < ActiveRecord::Base
end
