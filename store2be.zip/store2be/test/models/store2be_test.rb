require 'test_helper'

class Store2beTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
